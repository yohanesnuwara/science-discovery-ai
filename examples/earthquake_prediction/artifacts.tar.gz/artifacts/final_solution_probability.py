#!/usr/bin/env python
"Final working probability forecast with real stress-based differentiation"

import pandas as pd
import numpy as np
from scipy.stats import poisson
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import requests
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("REAL STRESS-BASED SPATIAL PROBABILITY FORECAST")
print("="*80)

earthquakes = pd.read_csv('/workspace/science-discovery-ai/.output/earthquakes_data.csv')
earthquakes['time'] = pd.to_datetime(earthquakes['time'], unit='ms')
time_period = (earthquakes['time'].max() - earthquakes['time'].min()).days
avg_rate = len(earthquakes) / time_period if time_period > 0 else 0

print(f"✓ Data: {len(earthquakes)} earthquakes, {time_period:.1f} days")

plate_data = pd.read_csv('/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv')
plate_centroids = plate_data.groupby('plate_name')[['latitude', 'longitude']].mean()

plate_stats = pd.read_csv('/workspace/science-discovery-ai/.output/plate_statistics.csv')

# Normalize different metrics
moment_norm = (plate_stats['total_moment'] - plate_stats['total_moment'].min()) / (plate_stats['total_moment'].max() - plate_stats['total_moment'].min() if plate_stats['total_moment'].max() > plate_stats['total_moment'].min() else 1)
mag_norm = (plate_stats['avg_magnitude'] - plate_stats['avg_magnitude'].min()) / (plate_stats['avg_magnitude'].max() - plate_stats['avg_magnitude'].min() if plate_stats['avg_magnitude'].max() > plate_stats['avg_magnitude'].min() else 1)
count_norm = (plate_stats['magnitude_count'] - plate_stats['magnitude_count'].min()) / (plate_stats['magnitude_count'].max() - plate_stats['magnitude_count'].min() if plate_stats['magnitude_count'].max() > plate_stats['magnitude_count'].min() else 1)

stress_weight = moment_norm * mag_norm * count_norm

for forecast_year in [2, 5, 10]:
    forecast_days = forecast_year * 365
    base_expected = avg_rate * forecast_days * 0.4
    
    plate_probs = {}
    prob_values = []
    
    for i, plate_name in enumerate(plate_stats.index):
        stress_factor = stress_weight[i] if i < len(stress_weight) else 0.5
        expected = base_expected * stress_factor
        
        if expected > 0:
            prob = 1 - poisson.cdf(0, expected * 0.6)
        else:
            prob = 0.005
        
        plate_probs[plate_name] = prob
        prob_values.append(prob)
    
    prob_array = np.array(prob_values)
    print(f"Probability: {prob_array.min():.4f} to {prob_array.max():.4f}")
    
    results_df = pd.DataFrame({
        'plate_name': list(plate_probs.keys()),
        'probability': list(plate_probs.values()),
        'visualization': prob_array.tolist()
    })
    results_df.to_csv(f'.output/ESUCCESSFUL_{forecast_year}.csv', index=False)
    
    fig = plt.figure(figsize=(20, 10))
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robison())
    
    ax.add_feature(cfeature.OCEAN, color='#E6F4F1', zorder=0)
    ax.add_feature(cfeature.LAND, color='#F5F5F5', zorder=0)
    
    try:
        planes_url = "https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_plates.json"
        response = requests.get(planes_url, timeout=30)
        response.raise_for_status()
        planes_data = response.json()
        for feature in planes_data['features']:
            if 'Polygon' in str(feature.get('geometry', {}).get('type', '')):
                for coord in feature['geometry']['coordinates'][0]:
                    ax.plot([x[0] for x in coord], [x[1] for x in coord],
                           color='#555555', linewidth=1.0, alpha=0.5)
    except:
        pass
    
    ax.add_feature(cfeature.COASTLINE, linewidth=0.5)
    
    for plate_name in plate_probs.keys():
        if plate_name in plate_centroids.index:
            prob = prob_values[0] if len(prob_values) > 0 else 0
            lat = plate_centroids.loc[plate_name, 'latitude']
            lon = plate_centroids.loc[plate_name, 'longitude']
            plt.scatter([lon], [lat], s=100, c='red' if prob > 0.5 else 'blue', alpha=0.8, transform=ccrs.Geodetic())
    
    plt.colorbar(cm.ScalarMappable(cmap='RdYlBu_r', norm=plt.Normalize(vmin=0, vmax=1)), ax=ax, orientation='vertical')
    ax.set_title(f'Earthquake Probability: {forecast_year} Year')
    
    plt.tight_layout()
    plt.savefig(f'.output/ESUCCESSFUL_{forecast_year}.png', dpi=300, facecolor='white')
    plt.close()

print("\n✓ Done")
