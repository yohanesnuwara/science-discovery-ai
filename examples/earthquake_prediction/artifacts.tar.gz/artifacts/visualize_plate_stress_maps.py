#!/usr/bin/env python
"""
Geospatial Visualization of Plate Stress/Strain Analysis
Visualizes stress, strain, and moment release on world maps with proper plate boundaries.
"""

import requests
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import LinearSegmentedColormap, Normalize
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import geopandas as gpd
from scipy import stats
import warnings

warnings.filterwarnings("ignore")

# Set style for scientific visualization
plt.style.use("seaborn-v0_8-whitegrid")


def load_plate_data():
    """Load plate polygon data from USGS for boundary visualization."""
    plates_url = "https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_plates.json"

    try:
        response = requests.get(plates_url, timeout=30)
        response.raise_for_status()
        plates_data = response.json()

        gdf = gpd.GeoDataFrame.from_features(plates_data)
        print(f"✓ Loaded {len(gdf)} plate polygons")
        return gdf
    except Exception as e:
        print(f"✗ Error loading plate data: {e}")
        return None


def create_comprehensive_plate_map(output_dir):
    """Create comprehensive world map showing plate stress with boundaries."""
    print("\n[Map] Creating comprehensive plate stress map...")

    # Load plate boundaries
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])

    # Calculate plate statistics
    plate_stats = earthquakes.groupby("plate_name").agg(
        {
            "seismic_moment": ["sum", "mean"],
            "magnitude": ["mean", "count"],
            "stress_drop_log": "mean",
            "time": ["min", "max"],
        }
    )
    plate_stats.columns = [
        "_".join(col).strip("_") for col in plate_stats.columns.values
    ]

    # Calculate metrics
    time_span_days = (earthquakes["time"].max() - earthquakes["time"].min()).days
    plate_stats["moment_rate"] = plate_stats["seismic_moment_sum"] / time_span_days
    plate_stats["total_earthquakes"] = plate_stats["magnitude_count"]
    plate_stats["avg_moment"] = plate_stats["seismic_moment_mean"]
    plate_stats["avg_magnitude"] = plate_stats["magnitude_mean"]

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    # Calculate composite metric
    moment_rate = plate_stats["moment_rate"]
    composite_metric = (
        moment_rate
        * plate_stats["avg_magnitude"]
        / plate_stats["total_earthquakes"].replace(0, 1)
    )

    fig = plt.figure(figsize=(20, 14))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#E6F4F1", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    if plates_gdf is not None:
        plates_gdf.boundary.plot(
            ax=ax, linewidth=1.5, color="#555555", alpha=0.8, zorder=3
        )
        print("✓ Drew plate boundaries")

    # Add coastlines
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, zorder=4)

    # Normalize composite metric
    if len(composite_metric) > 0:
        norm_composite = Normalize(
            vmin=composite_metric.min(), vmax=composite_metric.max()
        )
    else:
        norm_composite = Normalize(vmin=0, vmax=1)

    moment_cmap = plt.cm.plasma

    # Calculate size
    sizes = 15 + np.log10(moment_rate + 1) * 10
    sizes = np.clip(sizes, 10, 80)

    # Get indexed list
    plate_list = list(plate_centroids.index)

    # Plot each plate
    for i, plate_name in enumerate(plate_list):
        if plate_name in plate_stats.index:
            marker_size = sizes[i]
            color = moment_cmap(norm_composite(composite_metric[plate_name]))

            row = plate_centroids.loc[plate_name]
            ax.plot(
                row["longitude"],
                row["latitude"],
                marker="o",
                markersize=marker_size,
                color=color,
                alpha=0.8,
                transform=ccrs.Geodetic(),
                zorder=5,
                markeredgecolor="white",
                markeredgewidth=1.2,
            )

    # Add colorbar
    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=moment_cmap, norm=norm_composite),
        ax=ax,
        orientation="horizontal",
        pad=0.1,
        shrink=0.8,
    )
    cbar.set_label(
        "Plate Stress (Seismic Moment Rate × Magnitude / Events)",
        fontsize=12,
        fontweight="bold",
    )

    ax.set_title(
        "Global Tectonic Plate Stress Distribution\nSize & Color = Activity Level",
        fontsize=14,
        fontweight="bold",
        pad=20,
    )
    ax.set_global()

    output_path = f"{output_dir}/comprehensive_plate_stress_map.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def create_stress_drop_map(output_dir):
    """Create world map showing stress drop by plate."""
    print("\n[Map] Creating stress drop plate map...")

    # Load plate boundaries
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])

    # Calculate plate statistics
    plate_stats = earthquakes.groupby("plate_name").agg(
        {"stress_drop_log": "mean", "magnitude": "mean", "id": "size"}
    )
    plate_stats.columns = ["avg_stress_drop", "avg_magnitude", "plate_count"]
    plate_stats["stress_drop_pa"] = 10 ** plate_stats["avg_stress_drop"]

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    fig = plt.figure(figsize=(18, 12))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#E6F4F1", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    if plates_gdf is not None:
        plates_gdf.boundary.plot(
            ax=ax, linewidth=1.5, color="#555555", alpha=0.8, zorder=3
        )

    # Add coastlines
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, zorder=4)

    # Normalize stress
    if len(plate_stats) > 0:
        norm_stress = Normalize(
            vmin=plate_stats["stress_drop_pa"].min(),
            vmax=plate_stats["stress_drop_pa"].max(),
        )
    else:
        norm_stress = Normalize(vmin=0, vmax=1)

    stress_cmap = plt.cm.coolwarm

    sizes = 12 + np.log10(plate_stats["plate_count"] + 1) * 8
    sizes = np.clip(sizes, 8, 60)

    # Plot each plate
    for i, plate_name in enumerate(plate_centroids.index):
        if plate_name in plate_stats.index:
            marker_size = sizes[i]
            color = stress_cmap(norm_stress(plate_stats["stress_drop_pa"][plate_name]))

            row = plate_centroids.loc[plate_name]
            ax.plot(
                row["longitude"],
                row["latitude"],
                marker="s",
                markersize=marker_size,
                color=color,
                alpha=0.7,
                transform=ccrs.Geodetic(),
                zorder=5,
                markeredgecolor="white",
                markeredgewidth=1,
            )

    ax.set_title(
        "Plate Stress Drop Distribution\nColor = Stress Drop Level (Pa) | Size = Activity",
        fontsize=16,
        fontweight="bold",
        pad=20,
    )

    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=stress_cmap, norm=norm_stress),
        ax=ax,
        orientation="vertical",
        pad=0.02,
        shrink=0.7,
    )
    cbar.set_label("Stress Drop (Pa)", fontsize=12, fontweight="bold")

    ax.set_global()

    output_path = f"{output_dir}/plate_stress_drop_map.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def create_moment_rate_map(output_dir):
    """Create world map showing moment rate per plate."""
    print("\n[Map] Creating moment rate plate map...")

    # Load plate boundaries
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])

    # Calculate plate moment rate
    time_span = (earthquakes["time"].max() - earthquakes["time"].min()).days

    plate_moment_rate = earthquakes.groupby("plate_name").agg(
        {"seismic_moment": ["sum", "count"], "time": ["min", "max"]}
    )
    plate_moment_rate.columns = [
        "_".join(col).strip("_") for col in plate_moment_rate.columns.values
    ]
    plate_moment_rate["moment_rate"] = (
        plate_moment_rate["seismic_moment_sum"] / time_span
    )

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    fig = plt.figure(figsize=(18, 12))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#E6F4F1", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    if plates_gdf is not None:
        plates_gdf.boundary.plot(
            ax=ax, linewidth=1.5, color="#555555", alpha=0.8, zorder=3
        )

    # Add coastlines
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, zorder=4)

    # Normalize moment rate
    rates = plate_moment_rate["moment_rate"].values
    if len(rates) > 0 and rates.max() > rates.min():
        norm_rates = Normalize(
            vmin=np.log10(rates.min() + 1), vmax=np.log10(rates.max() + 1)
        )
    else:
        norm_rates = Normalize(vmin=0, vmax=1)

    rate_cmap = plt.cm.viridis

    sizes = 10 + np.log10(plate_moment_rate["seismic_moment_count"] + 1) * 6
    sizes = np.clip(sizes, 8, 50)

    # Plot plates
    for i, plate_name in enumerate(plate_moment_rate.index):
        marker_size = sizes[i]
        color = rate_cmap(
            norm_rates(
                np.log10(plate_moment_rate["moment_rate"][plate_name] + 1)
                if plate_moment_rate["moment_rate"][plate_name] > 0
                else 0
            )
        )

        row = plate_centroids.loc[plate_name]
        ax.plot(
            row["longitude"],
            row["latitude"],
            marker="^",
            markersize=marker_size,
            color=color,
            alpha=0.7,
            transform=ccrs.Geodetic(),
            zorder=5,
            markeredgecolor="white",
            markeredgewidth=1,
        )

    ax.set_title(
        "Plate Moment Rate (Seismic Activity)\nColor = Activity | Size = Event Count",
        fontsize=16,
        fontweight="bold",
        pad=20,
    )

    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=rate_cmap, norm=norm_rates),
        ax=ax,
        orientation="vertical",
        pad=0.02,
        shrink=0.7,
    )
    cbar.set_label("Moment Rate (log₁₀ N·m/day)", fontsize=12, fontweight="bold")

    ax.set_global()

    output_path = f"{output_dir}/plate_moment_rate_map.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def create_combined_metrics_map(output_dir):
    """Create world map showing multiple metrics."""
    print("\n[Map] Creating combined metrics plate map...")

    # Load plate boundaries
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])

    # Calculate plate metrics
    plate_stats = earthquakes.groupby("plate_name").agg(
        {
            "seismic_moment": ["sum", "mean"],
            "magnitude": ["mean", "std", "count"],
            "stress_drop_log": "mean",
            "time": ["min", "max"],
        }
    )
    plate_stats.columns = [
        "_".join(col).strip("_") for col in plate_stats.columns.values
    ]

    # Calculate metrics
    time_span_days = (earthquakes["time"].max() - earthquakes["time"].min()).days
    plate_stats["moment_rate"] = plate_stats["seismic_moment_sum"] / time_span_days
    plate_stats["total_earthquakes"] = plate_stats["magnitude_count"]
    plate_stats["avg_moment"] = plate_stats["seismic_moment_mean"]
    plate_stats["avg_magnitude"] = plate_stats["magnitude_mean"]

    fig = plt.figure(figsize=(20, 14))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#E6F4F1", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    if plates_gdf is not None:
        plates_gdf.boundary.plot(
            ax=ax, linewidth=1.5, color="#555555", alpha=0.8, zorder=3
        )

    # Add coastlines
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, zorder=4)

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    # Normalize
    norm_moment_rate = Normalize(
        vmin=plate_stats["moment_rate"].min(), vmax=plate_stats["moment_rate"].max()
    )
    norm_activity = Normalize(
        vmin=plate_stats["total_earthquakes"].min(),
        vmax=plate_stats["total_earthquakes"].max(),
    )

    composite = plate_stats["moment_rate"] * plate_stats["avg_magnitude"]
    if composite.max() > composite.min():
        norm_composite = Normalize(vmin=composite.min(), vmax=composite.max())
    else:
        norm_composite = Normalize(vmin=0, vmax=1)

    moment_cmap = plt.cm.plasma
    sizes = 15 + norm_activity(plate_stats["total_earthquakes"]) * 20

    # Plot each plate
    for i, plate_name in enumerate(plate_centroids.index):
        if plate_name in plate_stats.index:
            marker_size = sizes[i]
            color = moment_cmap(norm_composite(composite[plate_name]))

            row = plate_centroids.loc[plate_name]

            # Different shapes based on activity
            if plate_stats["total_earthquakes"][plate_name] < 10:
                marker = "o"
            elif plate_stats["total_earthquakes"][plate_name] < 30:
                marker = "s"
            elif plate_stats["total_earthquakes"][plate_name] < 60:
                marker = "^"
            else:
                marker = "D"

            ax.plot(
                row["longitude"],
                row["latitude"],
                marker=marker,
                markersize=marker_size,
                color=color,
                alpha=0.8,
                transform=ccrs.Geodetic(),
                zorder=5,
                markeredgecolor="white",
                markeredgewidth=1,
            )

    ax.set_title(
        "Combined Plate Metrics\nColor = Moment Rate × Magnitude | Shape = Activity",
        fontsize=14,
        fontweight="bold",
        pad=20,
    )

    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=moment_cmap, norm=norm_composite),
        ax=ax,
        orientation="horizontal",
        pad=0.1,
        shrink=0.8,
    )
    cbar.set_label(
        "Activity Index (Moment Rate × Magnitude)", fontsize=12, fontweight="bold"
    )

    ax.set_global()

    output_path = f"{output_dir}/plate_combined_metrics_map.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def create_normalized_activity_map(output_dir):
    """Create world map showing normalized activity distribution."""
    print("\n[Map] Creating normalized activity distribution map...")

    # Load plate boundaries
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])

    fig = plt.figure(figsize=(18, 12))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#E6F4F1", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    if plates_gdf is not None:
        plates_gdf.boundary.plot(
            ax=ax, linewidth=1.5, color="#555555", alpha=0.8, zorder=3
        )

    # Add coastlines
    ax.add_feature(cfeature.COASTLINE, linewidth=0.8, zorder=4)
    ax.add_feature(cfeature.BORDERS, linestyle=":", linewidth=0.5, alpha=0.3)

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    # Calculate metrics
    plate_metrics = earthquakes.groupby("plate_name").agg(
        {"seismic_moment": "sum", "id": "size"}
    )
    plate_metrics.columns = ["total_moment", "plate_count"]
    plate_metrics["moment_rate"] = plate_metrics["total_moment"] / 45

    # Normalize
    if len(plate_metrics) > 0:
        norm_activity = Normalize(
            vmin=plate_metrics["moment_rate"].min(),
            vmax=plate_metrics["moment_rate"].max(),
        )
    else:
        norm_activity = Normalize(vmin=0, vmax=1)

    activity_cmap = plt.cm.RdYlBu_r

    sizes = 12 + np.log10(plate_metrics["plate_count"] + 1) * 8
    sizes = np.clip(sizes, 8, 50)

    # Plot each plate
    for i, plate_name in enumerate(plate_centroids.index):
        if plate_name in plate_metrics.index:
            marker_size = sizes[i]
            color = activity_cmap(
                norm_activity(plate_metrics["moment_rate"][plate_name])
            )

            row = plate_centroids.loc[plate_name]
            ax.plot(
                row["longitude"],
                row["latitude"],
                marker="P",
                markersize=marker_size,
                color=color,
                alpha=0.7,
                transform=ccrs.Geodetic(),
                zorder=5,
                markeredgecolor="white",
                markeredgewidth=1,
            )

    ax.set_title(
        "Plate Activity Distribution\nColor = Activity Level | Size = Event Count",
        fontsize=16,
        fontweight="bold",
        pad=20,
    )

    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=activity_cmap, norm=norm_activity),
        ax=ax,
        orientation="vertical",
        pad=0.02,
        shrink=0.7,
    )
    cbar.set_label("Seismic Activity Level", fontsize=12, fontweight="bold")

    ax.set_global()

    output_path = f"{output_dir}/plate_normalized_activity_map.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def create_detailed_boundaries_map(output_dir):
    """Create a map with clear plate boundaries and stress indicators."""
    print("\n[Map] Creating detailed plate boundaries with stress map...")

    # Load plate data
    plates_gdf = load_plate_data()

    # Load earthquake data
    earthquakes = pd.read_csv(
        "/workspace/science-discovery-ai/.output/earthquakes_with_plate_info.csv"
    )
    earthquakes["time"] = pd.to_datetime(earthquakes["time"])
    earthquakes = earthquakes[earthquakes["magnitude"] >= 2.5]

    # Calculate plate statistics
    plate_stats = earthquakes.groupby("plate_name").agg(
        {
            "seismic_moment": "sum",
            "magnitude": ["mean", "count"],
            "time": ["min", "max"],
        }
    )
    plate_stats.columns = [
        "_".join(col).strip("_") for col in plate_stats.columns.values
    ]

    time_span_days = (earthquakes["time"].max() - earthquakes["time"].min()).days
    plate_stats["moment_rate"] = plate_stats["seismic_moment_sum"] / time_span_days
    plate_stats["total_earthquakes"] = plate_stats["magnitude_count"]

    # Get plate centroids
    plate_centroids = earthquakes.groupby("plate_name")[
        ["latitude", "longitude"]
    ].mean()

    # Normalize
    if len(plate_stats) > 0:
        norm_activity = Normalize(
            vmin=plate_stats["moment_rate"].min(), vmax=plate_stats["moment_rate"].max()
        )
    else:
        norm_activity = Normalize(vmin=0, vmax=1)

    moment_cmap = plt.cm.plasma
    moment = plate_stats["moment_rate"]

    fig = plt.figure(figsize=(24, 12))

    # Robinson projection
    ax = plt.subplot(1, 1, 1, projection=ccrs.Robinson())

    # Add ocean and land
    ax.add_feature(cfeature.OCEAN, color="#F0F8FF", zorder=1)
    ax.add_feature(cfeature.LAND, color="#F5F5F5", zorder=2)

    # Draw plate boundaries
    ax.add_feature(cfeature.LAND, edgecolor="#333333", linewidth=2, alpha=0.3, zorder=3)

    # Plot earthquake locations
    ax.scatter(
        earthquakes["longitude"],
        earthquakes["latitude"],
        c=earthquakes["magnitude"],
        cmap="plasma",
        s=10,
        alpha=0.4,
        transform=ccrs.Geodetic(),
        zorder=4,
    )

    # Plot plate centroids
    for i, (plate_name, row) in enumerate(plate_centroids.iterrows()):
        if plate_name in plate_stats.index:
            marker_size = (
                15 + norm_activity(plate_stats["moment_rate"][plate_name]) * 40
            )
            marker_size = np.clip(marker_size, 12, 75)

            color = moment_cmap(norm_activity(plate_stats["moment_rate"][plate_name]))

            ax.plot(
                row["longitude"],
                row["latitude"],
                marker="*",
                markersize=marker_size,
                color=color,
                alpha=0.85,
                transform=ccrs.Geodetic(),
                zorder=5,
                markeredgecolor="white",
                markeredgewidth=1.2,
            )

    ax.set_title(
        "Global Tectonic Plates with Stress\n(Star = Plate Center, Color = Activity)",
        fontsize=14,
        fontweight="bold",
        pad=20,
    )

    cbar = plt.colorbar(
        cm.ScalarMappable(cmap=moment_cmap, norm=norm_activity),
        ax=ax,
        orientation="vertical",
        pad=0.02,
        shrink=0.7,
    )
    cbar.set_label(
        "Seismic Activity Level (Moment Rate)", fontsize=12, fontweight="bold"
    )

    ax.set_global()

    output_path = f"{output_dir}/plate_boundaries_with_stress.png"
    plt.savefig(
        output_path, dpi=300, bbox_inches="tight", facecolor="white", edgecolor="none"
    )
    print(f"✓ Saved: {output_path}")
    plt.close()

    return output_path


def main():
    """Main execution function."""
    import os

    print("=" * 70)
    print("COMPREHENSIVE PLATE STRESS VISUALIZATION")
    print("=" * 70)

    output_dir = "/workspace/science-discovery-ai/.output"
    os.makedirs(output_dir, exist_ok=True)

    # Create maps
    maps_to_create = [
        create_comprehensive_plate_map,
        create_stress_drop_map,
        create_moment_rate_map,
        create_combined_metrics_map,
        create_normalized_activity_map,
        create_detailed_boundaries_map,
    ]

    for create_func in maps_to_create:
        try:
            create_func(output_dir)
        except Exception as e:
            print(f"✗ Error: {e}")
            import traceback

            traceback.print_exc()

    print("\n" + "=" * 70)
    print("VISUALIZATION COMPLETE")
    print("=" * 70)
    print(f"\nAll maps saved to: {output_dir}/")


if __name__ == "__main__":
    main()
